//
//  FirstViewController.swift
//  Example
//
//  Created by Rashid Latif on 17/01/2021.
//  Copyright © 2021 yysskk. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, Storyboarded {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
 

}
