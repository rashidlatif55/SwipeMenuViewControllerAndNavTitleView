//
//  FourthViewController.swift
//  Example
//
//  Created by Rashid Latif on 17/01/2021.
//  Copyright © 2021 yysskk. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController, Storyboarded {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}


import UIKit

/// A protocol that lets us instantiate view controllers from a storyboard.
protocol Storyboarded { }

extension Storyboarded where Self: UIViewController {
    // Creates a view controller from our storyboard. These methods relies on view controllers having the same storyboard identifier as their class name. This method shouldn't be overridden in conforming types.
    
    static func instantiateMain() -> Self {
        let storyboardIdentifier = String(describing: self)
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        
        // swiftlint:disable:next force_cast
        return storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
    }
    
    
    
}
