//
//  ThirdViewController.swift
//  Example
//
//  Created by Rashid Latif on 17/01/2021.
//  Copyright © 2021 yysskk. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController , Storyboarded{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
 

}
