import UIKit

final class ViewController: SwipeMenuViewController {
    
    @IBOutlet private weak var titleView: UIView!
    
    var options = SwipeMenuViewOptions()
    var vcArray = [UIViewController]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        self.navigationItem.titleView = self.titleView
        self.navigationItem.titleView?.layoutSubviews()
        titleView.frame = navigationItem.titleView!.bounds
        
        let first = FirstViewController.instantiateMain()
        first.title = "First"
        
        let second = SecondViewController.instantiateMain()
        second.title = "Second"
        
        let third = ThirdViewController.instantiateMain()
        third.title = "Third"
        
        let fourth = FourthViewController.instantiateMain()
        fourth.title = "Fourth"
        
        vcArray = [first,second,third,fourth]
        vcArray.forEach { (vc) in
            self.addChild(vc)
        }
        DispatchQueue.main.async {
            self.reload()
        }
    }
    
    
    private func reload() {
        options.tabView.addition = .circle
        options.tabView.margin = 20
        options.contentScrollView.isScrollEnabled = true
        options.tabView.itemView.selectedTextColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1.0)
        options.tabView.itemView.margin = 20
        options.tabView.itemView.width = 10
        options.tabView.height = 33
        options.tabView.needsAdjustItemViewWidth = false
        options.tabView.itemView.width = 116
        options.contentScrollView.backgroundColor = .red
        options.tabView.itemView.textColor = .red
        options.tabView.backgroundColor = .blue
        
        options.contentScrollView.isSafeAreaEnabled = true
        
        swipeMenuView.reloadData(options: options)
        
        self.swipeMenuView.layoutSubviews()
        self.swipeMenuView.layoutIfNeeded()
        
        
    }
    
    // MARK: - SwipeMenuViewDelegate
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewWillSetupAt currentIndex: Int) {
        super.swipeMenuView(swipeMenuView, viewWillSetupAt: currentIndex)
        print("will setup SwipeMenuView")
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewDidSetupAt currentIndex: Int) {
        super.swipeMenuView(swipeMenuView, viewDidSetupAt: currentIndex)
        print("did setup SwipeMenuView")
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, willChangeIndexFrom fromIndex: Int, to toIndex: Int) {
        super.swipeMenuView(swipeMenuView, willChangeIndexFrom: fromIndex, to: toIndex)
        print("will change from section\(fromIndex + 1)  to section\(toIndex + 1)")
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, didChangeIndexFrom fromIndex: Int, to toIndex: Int) {
        super.swipeMenuView(swipeMenuView, didChangeIndexFrom: fromIndex, to: toIndex)
        let vc = children[toIndex]
        switch toIndex {
        case 0:
            print("first")
        case 1:
            print("second")
            if let newVC = vc as? SecondViewController {
                newVC.mySring = "hello"
            }
        default:
            break
        }
        
        print("did change from section\(fromIndex + 1)  to section\(toIndex + 1)")
    }
    
    
    // MARK - SwipeMenuViewDataSource
    
    override func numberOfPages(in swipeMenuView: SwipeMenuView) -> Int {
        return vcArray.count
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, titleForPageAt index: Int) -> String {
        return children[index].title ?? ""
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewControllerForPageAt index: Int) -> UIViewController {
        let vc = children[index]
        vc.didMove(toParent: self)
        
        return vc
    }
}

class CustomTitleView: UIView {
    
    override var intrinsicContentSize: CGSize {
        return UIView.layoutFittingExpandedSize
    }
}
